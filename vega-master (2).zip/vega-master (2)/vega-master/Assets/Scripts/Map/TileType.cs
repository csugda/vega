﻿using UnityEngine;

namespace Assets.Scripts.Map
{
    public enum TileType
    {
        Floor, Border, InnerWall
    }
}
