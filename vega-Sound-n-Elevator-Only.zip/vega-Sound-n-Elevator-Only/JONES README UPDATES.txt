Audio files are under Assets-Audio-Edited SOund Effects

Elevator is under Assets-Resources-Elevator


The elevator is in blend format because exporting as obj made it into like 80 segment files.

	If the textures don't work, thats fine, I can figure it out in unity later, along with the animations. 