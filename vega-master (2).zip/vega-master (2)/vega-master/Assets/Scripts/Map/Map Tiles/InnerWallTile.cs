﻿namespace Assets.Scripts.Map.Map_Tiles
{
    public class InnerWallTile : MapTile
    {

    }
}
