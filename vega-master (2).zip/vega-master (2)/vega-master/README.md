# vega

Project Vega -- Home Repository.

Project Vega is a game created by the CSU Game Developers Association, Fall 2017


This project requires Unity 2017.1.1f1

Open in Unity by selecting this folder to open in Unity, or by opening any of the scenes in the Assets folder. 
